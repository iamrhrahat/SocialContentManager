<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('facebook_pages')): ?>
    <ul>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <input type="checkbox" name="pages[]" value="<?php echo e($page['id']); ?>">
                <?php echo e($page['name']); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\Web Development\myXmpp\htdocs\SocialContentManager\resources\views\account\accounts.blade.php ENDPATH**/ ?>
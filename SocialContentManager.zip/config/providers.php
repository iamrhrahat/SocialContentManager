<?php

return [

    'facebook' => [
        'app_id' => env('FACEBOOK_APP_ID'),
        'app_secret' => env('FACEBOOK_APP_SECRET'),
        'default_graph_version' => env('FACEBOOK_GRAPH_VERSION'),
        'app.url' => env('APP_URL'),
    ],

];
